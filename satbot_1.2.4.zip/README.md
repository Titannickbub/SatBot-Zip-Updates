# Sat Bot

Bot multi-plataforma para Discord, Telegram e WhatsApp, executado com
Node.js. O projeto oferece carregamento dinâmico de comandos, automações,
IA, downloads e suporte a Windows, Linux, macOS e Termux.

## Links

- Site: https://titannickbub.neocities.org/
- WhatsApp: https://chat.whatsapp.com/Kz372Jw4zax7Sik0wW8UpT
- Telegram: https://t.me/satela_chats
- Discord: https://discord.gg/yaC9CrgrF4

## Comece aqui

- [Instalação e configuração](./docs/instalacao.md)
- [Plataformas e downloads](./docs/plataformas.md)
- [Funcionalidades](./docs/funcionalidades.md)
- [Desenvolvimento e segurança](./docs/desenvolvimento.md)

## Atalho rápido

```bash
npm install
node index.js
```

No Windows, também é possível usar `start.bat`. Em sistemas Unix, use
`bash start.sh`.

## Changelogs

- [Versão 1.2](./changelog/1.2/README.md)
- [Versão 1.1](./changelog/1.1/README.md)
- [Versão 1.0](./changelog/1.0/README.md)

## Licença

Defina a licença antes da publicação pública. MIT é uma opção comum para
projetos open source.
