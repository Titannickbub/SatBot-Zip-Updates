# Plataformas

## Discord

Coloque o cargo do bot acima da maioria dos cargos da guild. As permissões
recomendadas são:

- gerenciar mensagens;
- ler mensagens e histórico;
- enviar mensagens;
- anexar arquivos;
- inserir links/embeds;
- ver canais;
- gerenciar cargos.

## WhatsApp

A integração usa Baileys e pode estar sujeita às regras do WhatsApp. Evite
flood, spam, links em massa e uso em muitos grupos simultaneamente. Não
publique tokens, sessões autenticadas ou logs sensíveis.

## Downloads com Bronxys

Os comandos de download usam a API da Bronxys:

- Site: https://api.bronxyshost.com.br/
- Configuração: `!setkey <nova_chave>`
- Saldo: `!testbronxys`

A API utiliza créditos, com custo aproximado de R$ 1 a cada 1.000 requisições.
